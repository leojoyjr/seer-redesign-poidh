# Asker logos

Seven real brand logos exported at 128 × 128 as transparent RGBA PNGs, with proportional scaling and centered padding. No AI generation or redrawing.

- **kleros** — Purple Symbol. [Official source page](https://kleros.io/brand-assets).
- **gnosis** — White unified wordmark. [Official source page](https://www.gnosis.io/media).
- **optimism** — Wordmark_light.png from official kit. [Official source page](https://optimism.io/brand).
- **gitcoin** — helmet-dark@3x.png (transparent version) from official kit. [Official source page](https://gitcoin.co/brand).
- **bankless** — Official website inline i-wordmark; white currentColor. [Official source page](https://www.bankless.com).
- **a16z** — Official website structured-data logo, original dark ink. [Official source page](https://a16z.com).
- **ethereum** — Purple transparent diamond. [Official source page](https://ethereum.org/assets).

Kleros, Gnosis, Optimism, Gitcoin and Ethereum were sourced from their official brand pages or kits. Bankless and a16z were sourced from their official websites because public downloadable logo kits were not located. The a16z asset retains its original dark ink and is most legible on a light surface.

Exact asset URLs are recorded in sources.json. Original downloaded artwork is preserved in sources/.
