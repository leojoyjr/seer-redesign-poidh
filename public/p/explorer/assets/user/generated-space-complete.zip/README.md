# Generated space assets

- hero-bg.webp: 1920 × 1080, opaque WebP.
- Five 64 × 64 SVGs: 2px rounded strokes, no fill, one color using currentColor.
- preview.html: local preview of the complete set.

The hero was generated using the built-in image_gen tool, then resized and encoded as WebP. The SVGs were authored directly as vectors.

To tint an SVG through CSS, inline it into the document and set color on the SVG or its parent. An SVG loaded through an img element does not inherit the page's currentColor.

## Final hero prompt

Use case: stylized-concept
Asset type: website hero background, landscape 16:9, intended final size 1920x1080.
Primary request: Huge dark planet horizon curving across the upper right, thin glowing violet atmosphere rim, soft volumetric light rays fanning from top right to lower left, faint starfield dust, vast empty dark left side, cinematic, ultra clean.
Composition/framing: Keep the entire left 45% nearly black, dark and empty for website text overlay. Planet curve and strongest atmosphere light are on the right, with the enormous planet extending beyond the top and right edges of the frame. Rays fade away before entering the left text area.
Color palette: near-black space, restrained violet atmosphere and subtle cool light.
Constraints: no text, no typography, no logos, no watermark, no UI, no extra planets. Create only the background image.

## Icon specifications from the screenshot

- icon-seer.svg: an eye formed from a line extending left and splitting into three branches on the right.
- icon-deep.svg: five vertical bars of different heights inside a rounded square.
- icon-futarchy.svg: one line forking into two curved branches.
- icon-opportunity.svg: three ranked horizontal bars, top longest, with a small star at its end.
- icon-risk.svg: a half-circle gauge with a needle and three ticks.

All requested assets from both screenshots are included.

## Additional generated assets

- aud-daos.webp: 800 × 520
- aud-funders.webp: 800 × 520
- aud-researchers.webp: 800 × 520
- aud-agents.webp: 800 × 520
- ecosystem-bg.webp: 1920 × 700

These five images were generated with the built-in image_gen tool and exported to WebP. Their final prompts and source provenance are in prompts-audience.json.
